<!DOCTYPE html>
<html lang="en">
<head>
<title>Support| Jallikattu</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/responsive.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
<script src="js/jquery.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.cookie.js"></script>
<script>
jQuery(window).load(function () {
    jQuery('.spinner').animate({
        'opacity': 0
    }, 1000, 'easeOutCubic', function () {
        jQuery(this).css('display', 'none')
    });
});
</script>
</head>
<body>
<div class="spinner"></div>
<!-- header -->
<header>
  <div class="container clearfix">
    <div class="row">
      <div class="span12">
        <div class="navbar navbar_">
          <div class="container">
            <h1 class="brand brand_"><a href="index.php"><img alt="" src="img/logo.png"> </a></h1>
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse_">Menu <span class="icon-bar"></span> </a>
            <div class="nav-collapse nav-collapse_  collapse">
              <ul class="nav sf-menu">
                <li><a href="message.php">Home</a></li>
                <li class="active"><a href="index.php">Message</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
<div class="bg-content">
  <!-- content -->
  <div id="content">
    <div class="ic"></div>
    <div class="container">
      <div class="row">
        <article class="span8">
          <h3>Contact us</h3>
          <div class="inner-1">
            <form id="contact-form" action="insert.php" method="POST">
              <div class="success"> Your message has been sent succesfuly!<strong> We will be in touch soon.</strong> </div>
              <fieldset>
                <div>
                  <label class="name">
                    <input type="text" name="place" placeholder="Place">
                    <br>
                    <span class="error">*This is not a valid name.</span> <span class="empty">*This field is required.</span> </label>
                </div>
                <div>
                  <label class="phone">
                    <input type="tel" name="mobile" placeholder="Telephone">
                    <br>
                    <span class="error">*This is not a valid phone number.</span> <span class="empty">*This field is required.</span> </label>
                </div>
                <div>
                  <label class="message">
                    <textarea name="content" placeholder="message" required></textarea>
                    <br>
                    <span class="error">*The message is too short.</span> <span class="empty">*This field is required.</span> </label>
                </div>
                </fieldset>
                <input type="submit">

                </form>
          
          </div>
        </article>
      </div>
    </div>
  </div>
</div>
<!-- footer -->
<footer>
  <div class="container clearfix">
    </ul>
    <div class="privacy pull-left">&copy; 2017 | <a href="">Support</a> | Jallikattu by <a href="">People of TN</a></div>
  </div>
</footer>
<script src="js/bootstrap.js"></script>
</body>
</html>