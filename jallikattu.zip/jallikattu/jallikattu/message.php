<!DOCTYPE html>
<html lang="en">
<head>
<title>Support Jallikattu</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/responsive.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/touchTouch.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/kwicks-slider.css" type="text/css" media="screen">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
<script src="js/jquery.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.flexslider-min.js"></script>
<script src="js/jquery.kwicks-1.5.1.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/touchTouch.jquery.js"></script>
<script>
if ($(window).width() > 1024) {
    document.write("<" + "script src='js/jquery.preloader.js'></" + "script>");
}
</script>
<script>
jQuery(window).load(function () {
    $x = $(window).width();
    if ($x > 1024) {
        jQuery("#content .row").preloader();
    }
    jQuery('.magnifier').touchTouch();
    jQuery('.spinner').animate({
        'opacity': 0
    }, 1000, 'easeOutCubic', function () {
        jQuery(this).css('display', 'none')
    });
});
</script>
</head>
<body>
<div class="spinner"></div>
<!-- header start -->
<header>
  <div class="container clearfix">
    <div class="row">
      <div class="span12">
        <div class="navbar navbar_">
          <div class="container">
            <h1 class="brand brand_"><a href="index.php"><img alt="" src="img/logo.png"> </a></h1>
            <a class="btn btn-navbar btn-navbar_" data-toggle="collapse" data-target=".nav-collapse_">Menu <span class="icon-bar"></span> </a>
            <div class="nav-collapse nav-collapse_  collapse">
              <ul class="nav sf-menu">
                <li class="active"><a href="index.php">Home</a></li>
                <li><a href="index.php">Message</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
<?php
$db=mysqli_connect('localhost','stude1','student','brogrammer') or die('Error connecting to MySQl server.');
$query="SELECT place,content FROM support order by count desc";
$result=mysqli_query($db,$query);
?>
    <div class="row-1">
      <div class="container">
        <div class="row">
          <article class="span12"><?php
while($row=mysqli_fetch_array($result)){
            ?>
            <h4><?php echo $row['place'];?></h4>
           </article>
          <pre><?php echo $row['content']; ?>
          </pre>
<?php } ?>
          </div>


      </div>
    </div>
      </div>
    </div>
  </div>
</div>

<!-- footer -->
<footer>
  <div class="container clearfix">
    
     <div class="privacy pull-left">&copy; 2017 | <a href="">Support</a> | Jallikattu by <a href="">People of TN</a></div>
  </div>
</footer>
<script src="js/bootstrap.js"></script>
</body>
</html>