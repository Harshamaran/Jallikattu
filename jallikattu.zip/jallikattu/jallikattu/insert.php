<?php
error_reporting(0);
mysql_connect("localhost","stude1","student") or die(mysql_error);
mysql_select_db("brogrammer") or die(mysql_error);
mysql_query("insert into support values(null,'$_POST[place]','$_POST[mobile]','$_POST[content]')");
header('location:message.php');
?>