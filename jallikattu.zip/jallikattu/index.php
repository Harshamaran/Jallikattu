<!DOCTYPE html>
<html lang="en">
<head>
<title>Support| Jallikattu</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/responsive.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
<script src="js/jquery.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.cookie.js"></script>
<script>
jQuery(window).load(function () {
    jQuery('.spinner').animate({
        'opacity': 0
    }, 1000, 'easeOutCubic', function () {
        jQuery(this).css('display', 'none')
    });
});
</script>
<style type="text/css"> .styled-button-1 { -webkit-box-shadow:rgba(0,0,0,0.2) 0 1px 0 0; -moz-box-shadow:rgba(0,0,0,0.2) 0 1px 0 0; box-shadow:rgba(0,0,0,0.2) 0 1px 0 0; color:#333; background-color:#FA2; border-radius:5px; -moz-border-radius:5px; -webkit-border-radius:5px; border:none; font-family:'Helvetica Neue',Arial,sans-serif; font-size:16px; font-weight:700; height:36px; padding:4px 16px; text-shadow:#FE6 0 1px 0 } </style>
</head>
<body>
<div class="spinner"></div>
<!-- header -->
<header>
  <div class="container clearfix">
    <div class="row">
      <div class="span12">
        <div class="navbar navbar_">
          <div class="container">
            <h1 class="brand brand_"><a href="index.php"><img alt="" src="img/logo.png"> </a></h1>
             
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse_">Menu <span class="icon-bar"></span> </a>
            <div class="nav-collapse nav-collapse_  collapse">
              <ul class="nav sf-menu">
                 
                <li><a href="message.php">View Messages</a></li>
                <li class="active"><a href="index.php">Share Ur Message</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
<div class="bg-content">
  <!-- content -->
  <div id="content">
    <div class="ic"></div>
    <div class="container">
      <div class="row">
        <article class="span8">
<br>
        <a href="http://jallikattu.forchange.in/message.php"> <button class=styled-button-1 >Click Here to View Messages </button></a>
<br><br>
       <a href="http://jallikattu.forchange.in/photos/index.php"> <button class=styled-button-1 >Click Here to Upload Images </button></a>

          <h3>Share your Messages</h3>
          <div class="inner-1">
            <form id="contact-form" action="insert.php" method="POST">
              
              <fieldset>
                <div>
                  <label class="name">
                    <input type="text" name="place" placeholder="Place" required>
                    <br>
                    </label>
                </div>
                <div>
                  <label class="phone">
                    <input type="tel" name="mobile" placeholder="Telephone">
                    <br>
                    </label>
                </div>
                <div>
                  <label class="message">
                    <textarea name="content" placeholder="message" required></textarea>
                    <br>
                     </label>
                </div>
                </fieldset>
                <input type="submit">

                </form>
          
          </div>
        </article>
      </div>
    </div>
  </div>
</div>
<!-- footer -->
<footer>
  <div class="container clearfix">
    </ul>
    <div class="privacy pull-left">&copy; 2017 | <a href="">Support</a> | Jallikattu by <a href="">People of TN</a></div>
  </div>
</footer>
<script src="js/bootstrap.js"></script>
</body>
</html>