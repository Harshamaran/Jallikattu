<?php
error_reporting(0);
mysql_connect("localhost","sgsmcet","sgs2017") or die(mysql_error);
mysql_select_db("sgs2017") or die(mysql_error);
mysql_query("insert into support values(null,'$_POST[place]','$_POST[mobile]','$_POST[content]')");
header('location:message.php');
?>